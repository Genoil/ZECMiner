#ifndef __WAGNER_CL_H__
#define __WAGNER_CL_H__
// RESTBITS determines how many digit-values share the same bucket
// the number of slots in a bucket is over-provisioned by a factor of 2,
// I figure 2^4 is big enough to spread out this allowance
// but perhaps much bigger values allow for better caching behaviour
#ifndef RESTBITS
#define RESTBITS        4
#endif

#ifndef DIGITBITS
#define WN				200
#define WK				9
#define NDIGITS			(WK+1)
#define	PROOFSIZE		(1<<WK)
#define DIGITBITS		(WN/NDIGITS)
#define BASE	 		(1<<DIGITBITS)
#define NHASHES 		(2*BASE)
#define HASHESPERBLAKE  (512/WN)
#define HASHOUT         (HASHESPERBLAKE*WN/8)
#endif

#define BUCKBITS        (DIGITBITS-RESTBITS)
#define NBUCKETS        (1<<BUCKBITS)
#define SLOTBITS        (RESTBITS+1+1)
#define NSLOTS          (1<<SLOTBITS)
#define XFULL           (NSLOTS/4)
#define SLOTMASK        (NSLOTS-1)
#define NRESTS          (1<<RESTBITS)
#define RESTMASK        (NRESTS-1)
#define NBLOCKS         ((NHASHES+HASHESPERBLAKE-1)/HASHESPERBLAKE)
// nothing larger found in 100000 runs
#define MAXSOLS	8

#ifdef __OPENCL_VERSION__
typedef uint u32;
typedef ulong uint64_t;
typedef uchar uint8_t;
typedef ushort uint16_t;

enum blake2b_constant
{
	BLAKE2B_BLOCKBYTES = 128,
	BLAKE2B_OUTBYTES = 64,
	BLAKE2B_KEYBYTES = 64,
	BLAKE2B_SALTBYTES = 16,
	BLAKE2B_PERSONALBYTES = 16
};

typedef struct __blake2b_state
{
	uint64_t h[8];
	uint8_t  buf[BLAKE2B_BLOCKBYTES];
	uint16_t counter;
	uint8_t  buflen;
	uint8_t  lastblock;
} blake2b_state;
#else

#ifndef ushort
typedef unsigned short ushort;
#endif

#ifndef ushort
typedef unsigned char uchar;
#endif
#endif

/*
typedef struct {
	ushort bucketid;	// : BUCKBITS; (no bitfields in OpenCL)
	uchar  slotid0;		// : SLOTBITS;
	uchar  slotid1;		// : SLOTBITS;
	uchar  xhash;		// : RESTBITS; 
} tree;
*/

typedef u32 tree;

typedef tree bucket[NSLOTS];
typedef bucket digit[NBUCKETS];

typedef u32 proof[PROOFSIZE];

u32 hashsize(const u32 r) {
	const u32 hashbits = WN - (r + 1) * DIGITBITS;
	return (hashbits + 7) / 8;
}

#endif